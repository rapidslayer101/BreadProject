"""
Whisper Interface ⢸⡇ IlloomAI⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀ ⢠⡄⠀⠀⠀⠀⠀⠀⢠⡄⢸⡇⢸⡇⠀Written by JakeR⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢠⡄⢸⡇⠀⠀⠀⠀⠀⠀⢸⡇⢸⡇⢸⡇⠀⠀⢸⡇⢀⡀⠀⠀⠀⠀⠀
⠀⢠⡄⢸⡇⢸⡇⢸⡇⢀⡀⢰⡆⢸⡇⢸⡇⢸⡇⢰⡇⢸⡇⢸⡇⢠⡀⠀⠀⠀
⠀⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⢸⡇⠀
⠀⠘⠃⢸⡇⢸⡇⢸⡇⠈⠁⢸⡇⢸⡇⢸⡇⢸⡇⠸⡇⢸⡇⢸⡇⠘⠁⠀⠀⠀
⠀⠀⠀⠈⠁⢸⡇⠀⠀⠀⠀⠀⠀⢸⡇⢸⡇⢸⡇⠀⠀⢸⡇⠈⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠘⠃⢸⡇⢸⠇⠀⠀⠀⠀⠀
                ⢸⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀
"""
import time

from Tools import DebugTool
import os
import torch
from transformers import AutoModelForSpeechSeq2Seq, AutoProcessor, pipeline
from git import Repo

supported_models = [{"Name": "openai/whisper-large-v3", "URL": "https://huggingface.co/openai/whisper-large-v3"}]


class SpeechToText:
    """
    HOLD UP!
    This is the base class, look at Server classes!
    You SHOULD NOT use this class unless you are making a custom interface.
    """

    def __init__(self, model_name, fast_attn=DebugTool.get_flash_attention_support()):
        self.check_model_exists(model_name)
        self.torch_dtype = torch.float16 if torch.cuda.is_available() else torch.float32

        self.device = "cuda:0" if torch.cuda.is_available() else "cpu"
        # Load the model from the specified path
        if fast_attn:
            print("Using fast attn")
            self.model = AutoModelForSpeechSeq2Seq.from_pretrained(self.model_path,
                                                                   torch_dtype=self.torch_dtype, low_cpu_mem_usage=True,
                                                                   use_safetensors=True,
                                                                   use_flash_attention_2=True)
        else:
            self.model = AutoModelForSpeechSeq2Seq.from_pretrained(self.model_path,
                                                                   torch_dtype=self.torch_dtype, low_cpu_mem_usage=True,
                                                                   use_safetensors=True)
            self.model.to(self.device)

        # Load the processor from the same path
        self.processor = AutoProcessor.from_pretrained(self.model_path)

        self.pipe = pipeline("automatic-speech-recognition", model=self.model, tokenizer=self.processor.tokenizer,
                             feature_extractor=self.processor.feature_extractor, max_new_tokens=128, chunk_length_s=30,
                             batch_size=16,
                             return_timestamps=True, torch_dtype=self.torch_dtype, device=self.device)

    def transcribe(self, audio_file_path):
        return self.pipe(audio_file_path)["text"]

    def check_model_exists(self, model_name):
        """
        Checks if a exists on disk
        """
        model = next((item for item in supported_models if item["Name"] == model_name), None)
        if model is None:
            raise FileNotFoundError(f"Unsupported Model")

        path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "models", model_name)
        if os.path.exists(path):
            print("Found model")
        else:
            print(f"Model not found, downloading {model_name}")
            os.makedirs(path, exist_ok=True)
            Repo.clone_from(model["URL"], path)
        self.model_path = path


if __name__ == '__main__':
    print("You are running AISDK.Base.SpeechToText as main, testing...")
    s = SpeechToText("openai/whisper-large-v3")
    t = time.time()
    transcript = s.transcribe("C:\\Users\\RARI\\Desktop\\Recording (7).mp3")
    print(f"{transcript}\nTime with fast attn: {time.time() - t}")
