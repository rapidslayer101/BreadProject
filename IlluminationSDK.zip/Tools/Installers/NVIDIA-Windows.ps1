# Check if nvcc.exe exists in the PATH
$nvccPath = Get-Command nvcc.exe -ErrorAction SilentlyContinue
if ($nvccPath) {
    Write-Host "CUDA Toolkit is already installed."
} else {
    Write-Host "Installing CUDA Toolkit..."
    winget install --id=Nvidia.CUDA  -e
}

Write-Host "Installing PyTorch CUDA"
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

Write-Host "Installing Llama-cpp-python"
$env:CMAKE_ARGS="-DLLAMA_CUBLAS=on"
pip install llama-cpp-python --force-reinstall --no-cache-dir


Write-Host "Installing Fast Attention, this may take a long time"
Write-Host "Kill this process (CTRL+C) if it takes 1 hour and your processor doesnt suck"
set MAX_JOBS=4
python -m pip install flash-attn --no-build-isolation


Write-Host "✨Your system is now AI Ready✨"
Write-Host "Run DebugTool.py to double check your config."