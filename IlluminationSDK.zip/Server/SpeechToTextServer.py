import os

import Base.SpeechToText as stt
from flask import Flask, request
import uuid

app = Flask(__name__)
Whisper = stt.SpeechToText("openai/whisper-large-v3")
os.makedirs(os.path.join(os.path.dirname(os.path.realpath(__file__)), "uploads"), exist_ok=True)
@app.route('/transcribeFromPath', methods=['GET'])
def transcribe():
    inp = request.args.get('path', '')
    if inp == '':
        return ("Missing parameter path")
    return Whisper.transcribe(inp)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part', 400

    file = request.files['file']
    if file.filename == '':
        return 'No selected file', 400

    # Process the file as needed, e.g., save to a directory
    filename = str(uuid.uuid4())
    file.save(os.path.join(os.path.dirname(os.path.realpath(__file__)), "uploads", filename + ".mp3"))

    return 'File uploaded successfully as ' + filename, 200

@app.route('/TranscribeFile', methods=['POST'])
def upload_file():
    #get file
    if 'file' not in request.files:
        return 'No file part', 400

    file = request.files['file']
    if file.filename == '':
        return 'No selected file', 400

    # save
    filepath = os.path.join(os.path.dirname(os.path.realpath(__file__)), "uploads", str(uuid.uuid4()) + ".mp3")
    file.save(filepath)

    #transcribe
    return Whisper.transcribe(filepath)


app.run()
